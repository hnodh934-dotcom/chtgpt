# 💬 تفعيل Live Chat (Crisp)

## الخطوات:

### 1️⃣ إنشاء حساب Crisp (مجاني)
1. اذهب إلى https://crisp.chat/en/
2. اضغط على "Start Free Trial"
3. سجل بريدك الإلكتروني وأنشئ حساب

### 2️⃣ الحصول على Website ID
1. بعد تسجيل الدخول، اذهب إلى Settings → Website Settings
2. انسخ **Website ID** (يبدأ بـ `xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx`)

### 3️⃣ إضافة Website ID في المنصة
1. افتح ملف `/home/ubuntu/regtech-compliance-platform/client/index.html`
2. ابحث عن `YOUR_CRISP_WEBSITE_ID` (السطر 15 تقريباً)
3. استبدله بـ Website ID الذي نسخته
4. احفظ الملف

### 4️⃣ إعادة تشغيل الخادم
```bash
cd /home/ubuntu/regtech-compliance-platform
pnpm dev
```

### 5️⃣ اختبار Live Chat
1. افتح المنصة في المتصفح
2. ستظهر أيقونة Chat في الزاوية السفلية اليمنى
3. اضغط عليها واكتب رسالة تجريبية
4. ستصلك الرسالة في لوحة تحكم Crisp

---

## ✅ الميزات المتاحة (مجاناً):

- ✅ **Unlimited conversations** - محادثات غير محدودة
- ✅ **2 agents** - وكيلان (موظفان)
- ✅ **Email notifications** - إشعارات بريد إلكتروني
- ✅ **Mobile apps** - تطبيقات جوال (iOS + Android)
- ✅ **Chatbot** - روبوت محادثة بسيط
- ✅ **Knowledge base** - قاعدة معرفية
- ✅ **Customization** - تخصيص الألوان والنصوص

---

## 🎨 تخصيص Live Chat:

في لوحة تحكم Crisp:
1. اذهب إلى Settings → Chatbox
2. غير اللون إلى **#10b981** (أخضر المنصة)
3. غير النص الترحيبي إلى: "مرحباً! كيف يمكننا مساعدتك؟"
4. فعّل "Show chatbox on mobile"

---

## 📊 التحليلات:

Crisp يوفر تحليلات مجانية:
- عدد المحادثات اليومية
- متوسط وقت الرد
- رضا العملاء
- أكثر الأسئلة شيوعاً

---

## 💡 نصائح:

1. **رد سريع**: حاول الرد خلال 5 دقائق لزيادة conversion rate
2. **Saved replies**: احفظ ردود جاهزة للأسئلة الشائعة
3. **Offline mode**: فعّل رسالة "نحن غير متصلين" خارج أوقات العمل
4. **Integration**: ربط Crisp مع Slack للحصول على إشعارات فورية

---

## 🔗 روابط مفيدة:

- Dashboard: https://app.crisp.chat/
- Documentation: https://docs.crisp.chat/
- Mobile Apps: https://crisp.chat/en/mobile/
